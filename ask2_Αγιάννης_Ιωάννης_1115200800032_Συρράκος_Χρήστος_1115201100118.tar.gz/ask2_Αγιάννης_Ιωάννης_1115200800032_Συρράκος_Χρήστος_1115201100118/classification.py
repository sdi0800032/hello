import csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


df=pd.read_csv('train.tsv',sep='\t');
df2=pd.read_csv('test.tsv',sep='\t');


attribute1 = pd.get_dummies(df['Attribute1'])
attribute2 = pd.cut(df['Attribute2'],bins=5)
attribute2 = pd.get_dummies(attribute2)
attribute3 = pd.get_dummies(df['Attribute3'])
attribute4 = pd.get_dummies(df['Attribute4'])
attribute5 = pd.cut(df['Attribute5'],bins=5)
attribute5 = pd.get_dummies(attribute5)
attribute6 = pd.get_dummies(df['Attribute6'])
attribute7 = pd.get_dummies(df['Attribute7'])
attribute8 = pd.get_dummies(df['Attribute8'])
attribute9 = pd.get_dummies(df['Attribute9'])
attribute10 = pd.get_dummies(df['Attribute10'])
attribute11 = pd.get_dummies(df['Attribute11'])
attribute12 = pd.get_dummies(df['Attribute12'])
attribute13 = pd.cut(df['Attribute13'],bins=5)
attribute13 = pd.get_dummies(attribute13)
attribute14 = pd.get_dummies(df['Attribute14'])
attribute15 = pd.get_dummies(df['Attribute15'])
attribute16 = pd.get_dummies(df['Attribute16'])
attribute17 = pd.get_dummies(df['Attribute17'])
attribute18 = pd.get_dummies(df['Attribute18'])
attribute19 = pd.get_dummies(df['Attribute19'])
attribute20 = pd.get_dummies(df['Attribute20'])

X_train =[attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,attribute8,attribute9,attribute10,attribute11,attribute12,attribute13,attribute14,attribute15,attribute16,attribute17,attribute18,attribute19,attribute20]
X_mat = pd.concat(X_train,axis=1)
X_mat = X_mat.as_matrix()
Y_mat = df['Label']




attribute_test1 = pd.get_dummies(df2['Attribute1'])
attribute_test2 = pd.cut(df2['Attribute2'],bins=5)
attribute_test2 = pd.get_dummies(attribute_test2)
attribute_test3 = pd.get_dummies(df2['Attribute3'])
attribute_test4 = pd.get_dummies(df2['Attribute4'])
attribute_test5 = pd.cut(df2['Attribute5'],bins=5)
attribute_test5 = pd.get_dummies(attribute_test5)
attribute_test6 = pd.get_dummies(df2['Attribute6'])
attribute_test7 = pd.get_dummies(df2['Attribute7'])
attribute_test8 = pd.get_dummies(df2['Attribute8'])
attribute_test9 = pd.get_dummies(df2['Attribute9'])
attribute_test10 = pd.get_dummies(df2['Attribute10'])
attribute_test11 = pd.get_dummies(df2['Attribute11'])
attribute_test12 = pd.get_dummies(df2['Attribute12'])
attribute_test13 = pd.cut(df2['Attribute13'],bins=5)
attribute_test13 = pd.get_dummies(attribute_test13)
attribute_test14 = pd.get_dummies(df2['Attribute14'])
attribute_test15 = pd.get_dummies(df2['Attribute15'])
attribute_test16 = pd.get_dummies(df2['Attribute16'])
attribute_test17 = pd.get_dummies(df2['Attribute17'])
attribute_test18 = pd.get_dummies(df2['Attribute18'])
attribute_test19 = pd.get_dummies(df2['Attribute19'])
attribute_test20 = pd.get_dummies(df2['Attribute20'])



X_test_train = [ attribute_test1, attribute_test2, attribute_test3, attribute_test4, attribute_test5, attribute_test6, attribute_test7, attribute_test8, attribute_test9, attribute_test10, attribute_test11, attribute_test12, attribute_test13, attribute_test14, attribute_test15, attribute_test16, attribute_test17, attribute_test18,attribute_test19,attribute_test20]

Xtest_mat = pd.concat(X_test_train, axis=1)
Xtest_mat = Xtest_mat.as_matrix()


from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report, accuracy_score


Fold_crossVal = StratifiedKFold( n_splits=10)
Fold_crossVals=Fold_crossVal.split(X_mat, Y_mat)
from sklearn import preprocessing, svm


SVMacc = 0
clfSVD = svm.SVC(kernel='rbf', C = 2.0, gamma='auto')
for i, (train, test) in enumerate(Fold_crossVals):

    clfSVD.fit(X_mat[train], Y_mat[train])
    preds = clfSVD.predict(X_mat[test])
    accSVM = accuracy_score(Y_mat[test], preds)
    SVMacc = SVMacc + accSVM


Fold_crossVal = StratifiedKFold( n_splits=10)
Fold_crossVals=Fold_crossVal.split(X_mat, Y_mat)
from sklearn.ensemble import RandomForestClassifier
RFacc = 0
clf5 = RandomForestClassifier(n_estimators=200, n_jobs=5)
for i, (train, test) in enumerate(Fold_crossVals):

    clf5.fit(X_mat[train], Y_mat[train])
    preds1 = clf5.predict(X_mat[test])
    accR = accuracy_score(Y_mat[test], preds1)
    RFacc = RFacc + accR

Fold_crossVal = StratifiedKFold( n_splits=10)
Fold_crossVals=Fold_crossVal.split(X_mat, Y_mat)
from sklearn.naive_bayes import MultinomialNB
NBacc = 0
clf2 = MultinomialNB()
for i, (train, test) in enumerate(Fold_crossVals):
    clf2 .fit(X_mat[train], Y_mat[train])
    pred2 = clf2 .predict(X_mat[test])
    accNV = accuracy_score(Y_mat[test], pred2)
    NBacc = NBacc + accNV

accSVM = SVMacc / 10
accRF = RFacc / 10
accNV = NBacc / 10





headers = ['Statistic M', 'SVM','Random Forest','Naive Bayes']

table = [['Accuracy', round(accSVM,3),round(accRF,3), round(accNV,3)]]
with open('EvaluationMetric_10fold.csv', 'w') as csvfile:
    writer = csv.writer(csvfile,delimiter='|')
    writer.writerow([u''.join(str(column).rjust(11)) for column in headers])
    for row in table:
        writer.writerow([u''.join(str(column).rjust(11)) for column in row])



clf5.fit(X_mat, Y_mat)
preds3 = clf5.predict(Xtest_mat)
predicted = []
i=0
for i in range(199):
    if preds3[i] == 2:
        predicted.append('Bad')
    else:
        predicted.append('Good')
id = df2['Id']

newDf = pd.DataFrame({'Client_ID':id,'Predicted_Label':predicted})
newDf.to_csv('testSet_Predictions.csv', sep='\t')


