
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np




df=pd.read_csv('train.tsv',sep='\t');


colors = ['b','r']


from random import randint
colors = ['#3DF735','#EC2504']


df.reset_index().pivot('index','Attribute1','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.ylabel('# of Applicants')
plt.savefig('Attribute1')

color = dict(boxes='DarkGreen', whiskers='DarkOrange',medians='DarkBlue', caps='Gray')
df.boxplot(column='Attribute2',by='Label',notch=True,sym='')
plt.savefig('Attribute2')

df.reset_index().pivot('index','Attribute3','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute3')

df.reset_index().pivot('index','Attribute4','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute4')

df.boxplot(column='Attribute5',by='Label',notch=True,sym='')
plt.savefig('Attribute5')

df.reset_index().pivot('index','Attribute6','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute6')

df.reset_index().pivot('index','Attribute7','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute7')

df.reset_index().pivot('index','Attribute8','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute8')

df.reset_index().pivot('index','Attribute9','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute9')

df.reset_index().pivot('index','Attribute10','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute10')

df.reset_index().pivot('index','Attribute11','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute11')

df.reset_index().pivot('index','Attribute12','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute12')

df.boxplot(column='Attribute13',by='Label',notch=True,sym='')
plt.savefig('Attribute13')

df.reset_index().pivot('index','Attribute14','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute14')

df.reset_index().pivot('index','Attribute15','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute15')

df.reset_index().pivot('index','Attribute16','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute16')

df.reset_index().pivot('index','Attribute17','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute17')

df.reset_index().pivot('index','Attribute18','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute18')

df.reset_index().pivot('index','Attribute19','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute19')

df.reset_index().pivot('index','Attribute20','Label').hist(bins=3,alpha=0.5,align='left',orientation='vertical',color='red')
plt.xlabel('Good                  Bad')
plt.ylabel('# of Applicants')
plt.savefig('Attribute20')



