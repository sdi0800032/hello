from sklearn import svm

from sklearn.datasets import make_blobs
from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import log_loss
from sklearn.model_selection import KFold
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.feature_extraction.text import TfidfVectorizer
from wordcloud import WordCloud, STOPWORDS
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn import metrics

import csv
from sklearn.metrics import precision_recall_fscore_support
from sklearn import metrics
from decimal import *
getcontext().prec = 2


import pandas as pd;
from sklearn.svm.libsvm import predict
from samba.tests import docs
df=pd.read_csv('train_test.csv',sep='\t');
df_test=pd.read_csv('test_set.csv',sep='\t')
for column in df.columns:
    print column


    
import numpy as np
A = np.array(df)

df.target_names=['Business','Football','Politics', 'Film',  'Technology']

#preprocessing
import matplotlib.pyplot as plt

my_additional_stop_words=['it','say','said','will','us','give']
stop_words = ENGLISH_STOP_WORDS.union(my_additional_stop_words)
count_vect = CountVectorizer(stop_words=stop_words)
count_vect.fit(df.Content)
X_train_counts = count_vect.transform(df.Content)




vectorizer = TfidfVectorizer(stop_words=stop_words)
vectorizer.fit_transform(df.Content)
X_train_tfidf = vectorizer.transform(df.Content)




vec_new_test = TfidfVectorizer(stop_words=stop_words)
vec_new_test.fit_transform(df_test.Content)
X_new_counts_test = vectorizer.transform(df_test.Content)


y = pd.factorize(df.Category)[0]

svd = TruncatedSVD(n_components=500)
X_lsi = svd.fit_transform(X_train_tfidf)

X_lsi_test = svd.fit_transform(X_new_counts_test)






# SVM

clfSVD=SGDClassifier(loss='hinge', penalty='l2', alpha=1e-3, n_iter=5, random_state=42)\
         .fit(X_lsi,df.Category)
clfSVD = GaussianNB().fit(X_lsi, df.Category)


predictedSVD = clfSVD.predict(X_lsi_test)
psiSVD= pd.factorize(predictedSVD)[0]

predictedSVD1 = clfSVD.predict(X_lsi)
psiS= pd.factorize(predictedSVD1)[0]

precSVM ,recSVM ,fSVM ,supp=precision_recall_fscore_support(y, psiS, average='macro')
accSVM=accuracy_score(y, psiS)
fprS, tprS, thresholdsS = metrics.roc_curve(y, psiS, pos_label=2)
roc_aucS = metrics.auc(fprS, tprS)
print roc_aucS


import matplotlib.pyplot as plt
plt.title('Receiver Operating Characteristic')
plt.plot(fprS, tprS, 'b', label = 'AUC = %0.2f' % roc_aucS)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.savefig('Roc_SVD')


headers = ['  ID   ', 'Predicted Category']

with open('testSet_categoriesSVD.csv', 'wb') as csvfile:
    writer = csv.writer(csvfile,delimiter='\t')
    writer.writerow([u''.join(str(column).rjust(11)) for column in headers])
    for x in range(len(df_test.Id)):
	    writer.writerow([u''.join(str(df_test.Id[x])).rjust(11)])
	    writer.writerow([u''.join(str(predictedSVD[x])).rjust(11)])


# ///

#print y
#clf=svm.SVC(C=1.0, cache_size=200, class_weight=None, coef0=0.0,
 #   decision_function_shape=None, degree=3, gamma='auto', kernel='rbf',
  #  max_iter=-1, probability=False, random_state=None, shrinking=True,
   # tol=0.001, verbose=False)
#clf = svm.SVC( random_state=42,tol=1e-3 ,kernel='linear',C =1.0 )
#clf.fit(X_train_counts, y)  

#predicted=clf.predict(X_new_counts2)
#print predicted
# print clf.n_support_

# NAIVE BAYES




clf2 = MultinomialNB().fit(X_train_counts, df.Category)


predicted2 = clf2.predict(X_new_counts_test)
psi2 = pd.factorize(predicted2)[0]

predictedNV= clf2.predict(X_train_counts)
psiNV= pd.factorize(predictedNV)[0]

precNV ,recNV ,fNV ,supp=precision_recall_fscore_support(y, psiNV, average='macro')
accNV=accuracy_score(y, psiNV)
fprNV, tprNV, thresholdsNV = metrics.roc_curve(y, psiNV, pos_label=2)
roc_aucNV = metrics.auc(fprNV, tprNV)
print roc_aucNV


plt.title('Receiver Operating Characteristic')
plt.plot(fprNV, tprNV, 'b', label = 'AUC = %0.2f' % roc_aucNV)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.savefig('Roc_NV')


headers = ['  ID   ', 'Predicted Category']

with open('testSet_categoriesNV.csv', 'wb') as csvfile:
    writer = csv.writer(csvfile,delimiter='\t')
    writer.writerow([u''.join(str(column).rjust(11)) for column in headers])
    for x in range(len(df_test.Id)):
	    writer.writerow([u''.join(str(df_test.Id[x])).rjust(11)])
	    writer.writerow([u''.join(str(predicted2[x])).rjust(11)])



# /////


# gnb = GaussianNB()
# y_pred = gnb.fit(x2, df.Category).predict(x3)
# print y_pred

# //////




#RANDOM FOREST

ya = pd.factorize(df.Category)[0]

clf5 = RandomForestClassifier(n_jobs=5)
clf5.fit(X_lsi, ya)
clf5.predict(X_lsi_test)
for t in range(len(df_test.Id)):
	preds = df.target_names[clf5.predict(X_lsi_test)[t]]

#	print ""

clf5 = RandomForestClassifier(n_jobs=5)
clf5.fit(X_lsi, ya)
preds1=clf5.predict(X_lsi)



psi= pd.factorize(preds1)[0]

precR ,recR ,fR ,supp=precision_recall_fscore_support(ya, preds1, average='macro')
accR=accuracy_score(ya, preds1)
fpr, tpr, thresholds = metrics.roc_curve(ya, psi, pos_label=2)
roc_aucR = metrics.auc(fpr, tpr)
print roc_aucR




import matplotlib.pyplot as plt
plt.title('Receiver Operating Characteristic')
plt.plot(fpr, tpr, 'b', label = 'AUC = %0.2f' % roc_aucR)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.savefig('Roc_FOREST')


headers = ['  ID   ', 'Predicted Category']

with open('testSet_categoriesFOREST.csv', 'wb') as csvfile:
    writer = csv.writer(csvfile,delimiter='\t')
    writer.writerow([u''.join(str(column).rjust(11)) for column in headers])
    for x in range(len(df_test.Id)):
	    writer.writerow([u''.join(str(df_test.Id[x])).rjust(11)],)
	    writer.writerow([u''.join(str(df.target_names[clf5.predict(X_lsi_test)[x]])).rjust(11)])


#num_folds = 10
#subset_size = len(df)/num_folds

#kf = KFold(n_splits=10)
#for training_this_round, testing_this_round in kf.split(df.Content):
#	print training_this_round , testing_this_round
#	vec_new_test1 = TfidfVectorizer(stop_words=stop_words)
#	vec_new_test1.fit_transform(testing_this_round)
#	X_new_counts_test1 = vectorizer.transform(testing_this_round)

#	vec_new_train1 = TfidfVectorizer(stop_words=stop_words)
#	vec_new_train1.fit_transform(training_this_round)
#	X_new_counts_train1 = vectorizer.transform(training_this_round)
#
#	svd = TruncatedSVD(n_components=500)
#	X_lsi_train1 = svd.fit_transform(X_new_counts_train1)

#	X_lsi_test1 = svd.fit_transform(X_new_counts_test1)
#	clf5 = RandomForestClassifier(n_jobs=5)
#	clf5.fit(X_lsi_train1, ya)
#	clf5.predict(X_lsi_test1)
#	print clf5.predict_proba(X_lsi_test1)



#eektupwsi apotelesmatwn gia Evaluation
headers = ['Statistic M', 'SVM','Naive Bayes','Random Forest']

table = [['Accuracy', round(accSVM,2), round(accNV,2),round(accR,2)],
        ['Precision', round(precSVM,2), round(precNV,2),round(precR,2)],
        ['Recall', round(recSVM,2),  round(recNV,2), round(recR,2)],
        ['F-Measure', round(fSVM,2), round(fNV,2),round(fR,2)],
        ['AUC', round(roc_aucS,2), round(roc_aucNV,2),round(roc_aucR,2)],
        ]

with open('EvaluationMetric_10fold.csv', 'w') as csvfile:
    writer = csv.writer(csvfile,delimiter='|')
    writer.writerow([u''.join(str(column).rjust(11)) for column in headers])
    for row in table:
        writer.writerow([u''.join(str(column).rjust(11)) for column in row])


