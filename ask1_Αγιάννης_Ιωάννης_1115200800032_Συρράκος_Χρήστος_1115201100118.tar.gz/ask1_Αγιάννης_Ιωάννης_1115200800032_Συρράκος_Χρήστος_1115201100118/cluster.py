from __future__ import division

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

from wordcloud import WordCloud, STOPWORDS
from sklearn.feature_extraction import stop_words
from nltk.app.wordnet_app import SIMILAR
from sklearn.metrics.pairwise import cosine_similarity
from scipy import sparse
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.feature_extraction.text import TfidfVectorizer

from nltk.cluster import KMeansClusterer, cosine_distance 
from nltk import cluster
from numpy import array


import pandas as pd;
df=pd.read_csv('train_set.csv',sep='\t');
df

    
import numpy as np


A = np.array(df)


df.target_names=['Politics', 'Film', 'Football', 'Business','Technology']
from decimal import *
getcontext().prec = 2

import matplotlib.pyplot as plt


my_additional_stop_words=['it','say','said','will','us','give']
stop_words = ENGLISH_STOP_WORDS.union(my_additional_stop_words)

vectorizer = TfidfVectorizer(stop_words=stop_words)
vectorizer.fit_transform(df.Content)
X_train_tfidf = vectorizer.transform(df.Content)

svd = TruncatedSVD(n_components=500)
X_lsi = svd.fit_transform(X_train_tfidf)

A_sparse = sparse.csr_matrix(X_lsi)
similarities = cosine_similarity(A_sparse)




#clustering 

clusterer = cluster.KMeansClusterer(5, cosine_distance) 
clusters = clusterer.cluster(similarities, True, trace=True) 


Matrix = [[0 for x in range(6)] for y in range(5)] 


for i in range(len(df.Id)):

    if df.Category[i]=='Politics':
        Matrix[clusters[i]][0]=1+Matrix[clusters[i]][0]
    if df.Category[i]=='Business':
        Matrix[clusters[i]][1]=1+Matrix[clusters[i]][1]
    if df.Category[i]=='Football':
        Matrix[clusters[i]][2]=1+Matrix[clusters[i]][2]
    if df.Category[i]=='Film':
        Matrix[clusters[i]][3]=1+Matrix[clusters[i]][3]
    if df.Category[i]=='Technology':
        Matrix[clusters[i]][4]=1+Matrix[clusters[i]][4]
    Matrix[clusters[i]][5]=1+Matrix[clusters[i]][5]

x , y =0 ,0;        
         
import csv



headers = ['    ', 'Politics', 'Business','Football','Film','Technology']
table = [['Cluster1', Matrix[0][0], Matrix[0][1],Matrix[0][2],Matrix[0][3],Matrix[0][4]],
        ['Cluster2', Matrix[1][0], Matrix[1][1],Matrix[1][2],Matrix[1][3],Matrix[1][4]],
        ['Cluster3', Matrix[2][0],  Matrix[2][1], Matrix[2][2], Matrix[2][3], Matrix[2][4]],
        ['Cluster4', Matrix[3][0], Matrix[3][1],Matrix[3][2],Matrix[3][3],Matrix[3][4]],
        ['Cluster5', Matrix[4][0], Matrix[4][1],Matrix[4][2],Matrix[4][3],Matrix[4][4]],
        ]

             

with open('clustering_KMeans.csv', 'w') as csvfile:
    writer = csv.writer(csvfile,delimiter='|')
    writer.writerow([u''.join(str(column).rjust(11)) for column in headers])
    for row in table:
        writer.writerow([u''.join(str(column).rjust(11)) for column in row])
        

# y = pd.factorize(df.Category)[0]
# vectorizer2 = CountVectorizer(min_df=1)
# X_review_train = vectorizer2.fit_transform(df.Content)
# review = X_review_train.toarray()
# svd = TruncatedSVD(n_components=5, random_state=42)
# review = svd.fit_transform(review)
# print('transformed to vector, start to cluster')
# clusterer = GAAClusterer(num_clusters=3)
# clusterer = KMeansClusterer(5, cosine_distance, repeats=100)
# clusters = clusterer.cluster(review, True)
# print clusters
# print('finished clustering, start dendrogram')

