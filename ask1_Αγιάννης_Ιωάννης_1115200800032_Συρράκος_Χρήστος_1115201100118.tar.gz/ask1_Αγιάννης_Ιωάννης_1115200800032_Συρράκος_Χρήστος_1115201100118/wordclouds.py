from __future__ import division

from sklearn.feature_extraction import stop_words
from nltk.app.wordnet_app import SIMILAR
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.feature_extraction.text import TfidfVectorizer

import pandas as pd;
df=pd.read_csv('train_set.csv',sep='\t');
df

    
import numpy as np


A = np.array(df)


df.target_names=['Politics', 'Film', 'Football', 'Business','Technology']





my_additional_stop_words=['it','say','said','will','us','give']
stop_words = ENGLISH_STOP_WORDS.union(my_additional_stop_words)




vectorizer = TfidfVectorizer(stop_words=stop_words)
vectorizer.fit_transform(df.Content)
X_train_tfidf = vectorizer.transform(df.Content)

svd = TruncatedSVD(n_components=100)
X_lsi = svd.fit_transform(X_train_tfidf)


 
from os import path
basin =""
strs = ["" for p in range(5)]

for index, row in df.iterrows():
    if row['Category']=='Politics':
        strs[0] += row['Content']
    if row['Category']=='Football':
        strs[1] += row['Content']
    if row['Category']=='Film':
        strs[2] += row['Content']
    if row['Category']=='Business':
        strs[3] += row['Content']
    if row['Category']=='Technology':
        strs[4] += row['Content']   


for p in range(5):
    print 'here'
    wordcloud = WordCloud(
                              stopwords=stop_words,
                              background_color='white',
                              width=1200,
                              height=1000
                             ).generate(strs[p])
    
    
    plt.imshow(wordcloud)
    plt.axis('off')
    plt.savefig('Wordcloud'+str(p))

