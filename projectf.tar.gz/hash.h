#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

struct vectors {
  double *vector_coords;
};

typedef struct vectors *vector_ptr;


struct COS_items {
	double **item_array;
	int current_items;
	int current_dimension;
	int total_dimensions;
};

struct R_i {
	double **values;
	int current_Rdimension;
	int current_Kposition;
	};

struct random_T{
	double *t;	
};

struct random_r{
	long *r_euc;	
};

struct hashing_functions{
	long *hash_h;	
};

struct query_vectors{
	double *q_vectors;
	int q_elements;
	int q_radius;
};

struct query_distance{
	double *q_distance;
	int *q_dist_id;
	int q_current_items;
};

typedef struct COS_items *cos_items_ptr;	// array of vectors
typedef struct R_i **Ri_ptr;				// L arrays of D r_i's ( L:sizeo f HT , D: total dimensions of vectors)
typedef struct random_T *random_t_ptr ;
typedef struct random_r *random_rptr ;
typedef struct hashing_functions *hash_h_ptr;
typedef struct query_vectors *query_items_ptr;
typedef struct query_distance *query_dist_ptr ;

//Vectors

query_items_ptr allocate_space_query( char * , int , int);
cos_items_ptr allocate_space_items( int ) ;
Ri_ptr allocate_space_Ri(int , int , int);
void store_item_coords( double  , cos_items_ptr) ;
void build_Ri( int , int , Ri_ptr , cos_items_ptr , int , int  , vector_ptr , int , int , double , random_t_ptr , random_rptr ) ;
void store_Ri_coords( double , Ri_ptr , int );
void build_Hi_cosine( cos_items_ptr , Ri_ptr , int , int  , int , vector_ptr , int);
void build_Hi_euclidean( cos_items_ptr , Ri_ptr , int , int  , int , vector_ptr , int , double , int , random_t_ptr , random_rptr  , int);
double create_t(int);



//objects of the bucket
struct bucketmember{
        int key;
        vector_ptr v_ptr;
};


typedef struct bucketmember BucketMember;
BucketMember **global_bucket_key ;
//the bucket
struct bucket {
        BucketMember * bucketarray;
        int count;
        int size;
};

typedef struct bucket Bucket;

//o pinakas twn bucket kathe thesh deixnei se ena bucket
Bucket *** BucketArray;
Bucket * p;
hash_h_ptr hash_ptr;
random_t_ptr tptr;
query_dist_ptr dptr;

struct infos {
     int startbucketsize ;
     int countentries;
} Infos;



// HASHTABLE
void initHashtable(int , int );
int find_bucket_cosine(int  , cos_items_ptr  , Ri_ptr  , int  , int);
int find_bucket_euclidean(int  , cos_items_ptr  , Ri_ptr  , int  , int , random_t_ptr , random_rptr , int);
int searchHashtable_cosine(int ,cos_items_ptr  , Ri_ptr  , int ,int);
int searchHashtable_euclidean(int ,cos_items_ptr  , Ri_ptr  , int ,int , random_t_ptr , random_rptr , int);
void bucketentry( vector_ptr , int , int , int );
void putinbucket(BucketMember, int , int);
void freememory();
int mod (long a, long b);





//query
void queryfile_parsing( FILE *) ;
int find_query_buckets_euclidean(int , query_items_ptr  , random_t_ptr  , random_rptr  , Ri_ptr  , int , int   , int , int);
void find_distance_euclidean( int , query_items_ptr , int , int  ,int , int);
int find_query_bucket_cosine(int , query_items_ptr   , Ri_ptr  , int  , int , int);
void find_distance_cosine( query_items_ptr  , int  , int  , int  , int );
void real_distance( query_items_ptr , cos_items_ptr , FILE* , int);
